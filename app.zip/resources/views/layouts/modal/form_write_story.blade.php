<div class="modal modal-blur fade" id="modal--write--story" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">{{ __('main.write_a_story') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <!-- if you are not logged in -->
            @if(!Auth::check())
            <form action="{{ url('write') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">

                        <div class="mb-3">
                            <input type="text" class="form-control form-control-lg @error('title', 'write') is-invalid @enderror" name="title" value="{{ old('title') }}" placeholder="{{ __('main.title') }}">

                            @error('title', 'write')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                        </div>

                        <div class="mb-3">
                            <textarea class="form-control form-control-lg @error('story', 'write') is-invalid @enderror" name="story" rows="6" placeholder="{{ __('main.story') }}">{{ old('story') }}</textarea>

                            @error('story', 'write')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                        </div>

                        <div class="mb-3">
                            <label class="form-label">{{ __('main.choose_a_photo') }}</label>
                            <input type="file" name="photo" class="form-control @error('photo', 'write') is-invalid @enderror" accept="image/*">

                            @error('photo', 'write')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                            <small class="form-hint">
                                {{__('main.extensions_allowed')}}
                            </small>
                        </div>

                        <div class="mb-3">
                            <div class="col">
                                <div class="form-selectgroup form-selectgroup-pills @error('category_id', 'write') is-invalid @enderror">
                                @foreach($categories as $category)
                                <label class="form-selectgroup-item">
                                    <input type="radio" id="category_id" name="category_id" value="{{ $category->id }}" class="form-selectgroup-input"  @if(0<$category->score) disabled @endif>
                                    <span class="form-selectgroup-label" @if(0<$category->score) data-bs-toggle="tooltip" data-bs-html="true" title="{{ __('points.form_notice1') }}" @endif>
                                        {{ $category->name }}
                                        </span>
                                        </label>
                                    @endforeach
                                    </div>

                                    @error('category_id', 'write')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror

                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">{{ __('main.tags') }}</label>
                            <input type="text" class="form-control @error('tags') is-invalid @enderror" name="tags" placeholder="{{ __('main.separate_tag') }}" value="{{ old('tags') }}">
                        </div>

                    </div>
                    <input type="hidden" name="user_" value="130">
                    <input type="hidden" name="genders_id" value="3">
                    <input type="hidden" name="age" value="2000-01-01">
                    
                    <div class="modal-footer">

                   

                        <button type="submit" class="btn btn-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><circle cx="12" cy="12" r="9"></circle><line x1="9" y1="12" x2="15" y2="12"></line><line x1="12" y1="9" x2="12" y2="15"></line></svg> {{ __('main.btn_send') }}
                        </button>
                    </div>
                            
            </form>
            <!-- if you have not set gender and birth -->
            @elseif(empty(Auth::user()->genders_id) | empty(Auth::user()->birth))
            <form action="{{ url('write') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">

                        <div class="mb-3">
                            <input type="text" class="form-control form-control-lg @error('title', 'write') is-invalid @enderror" name="title" value="{{ old('title') }}" placeholder="{{ __('main.title') }}">

                            @error('title', 'write')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                        </div>

                        <div class="mb-3">
                            <textarea class="form-control form-control-lg @error('story', 'write') is-invalid @enderror" name="story" rows="6" placeholder="{{ __('main.story') }}">{{ old('story') }}</textarea>

                            @error('story', 'write')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                        </div>

                        <div class="mb-3">
                            <label class="form-label">{{ __('main.choose_a_photo') }}</label>
                            <input type="file" name="photo" class="form-control @error('photo', 'write') is-invalid @enderror" accept="image/*">

                            @error('photo', 'write')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                            <small class="form-hint">
                                {{__('main.extensions_allowed')}}
                            </small>
                        </div>

                        <div class="mb-3">
                            <div class="col">
                                <div class="form-selectgroup form-selectgroup-pills @error('category_id', 'write') is-invalid @enderror">
                                @foreach($categories as $category)
                                <label class="form-selectgroup-item">
                                    <input type="radio" id="category_id" name="category_id" value="{{ $category->id }}" class="form-selectgroup-input" {{ old('category_id') == $category->id ? 'checked' : '' }} @if(Auth::user()->total_point_count()<$category->score) disabled @endif>
                                    <span class="form-selectgroup-label" @if(Auth::user()->total_point_count()<$category->score) data-bs-toggle="tooltip" data-bs-html="true" title="{{ __('points.form_notice1') }}" @endif>
                                        {{ $category->name }}
                                        </span>
                                        </label>
                                    @endforeach
                                    </div>

                                    @error('category_id', 'write')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror

                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">{{ __('main.tags') }}</label>
                            <input type="text" class="form-control @error('tags') is-invalid @enderror" name="tags" placeholder="{{ __('main.separate_tag') }}" value="{{ old('tags') }}">
                        </div>

                    </div>
                    
                    <input type="hidden" name="genders_id" value="1">
                    <input type="hidden" name="age" value="20">
                    
                    <div class="modal-footer">

                        <!-- public -->
                        <label class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="public" value="1" {{ old('public') ? 'checked' : null }}>
                            <span class="form-check-label">Hiện danh tính của tôi</span>
                        </label>
                        <!-- end public -->

                        <button type="submit" class="btn btn-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><circle cx="12" cy="12" r="9"></circle><line x1="9" y1="12" x2="15" y2="12"></line><line x1="12" y1="9" x2="12" y2="15"></line></svg> {{ __('main.btn_send') }}
                        </button>
                    </div>
                            
            </form>
            @else
            <!-- write story -->
            @if($status_write == 1)
                <form action="{{ url('write') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">

                        <div class="mb-3">
                            <input type="text" class="form-control form-control-lg @error('title', 'write') is-invalid @enderror" name="title" value="{{ old('title') }}" placeholder="{{ __('main.title') }}">

                            @error('title', 'write')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                        </div>

                        <div class="mb-3">
                            <textarea class="form-control form-control-lg @error('story', 'write') is-invalid @enderror" name="story" rows="6" placeholder="{{ __('main.story') }}">{{ old('story') }}</textarea>

                            @error('story', 'write')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                        </div>

                        <div class="mb-3">
                            <label class="form-label">{{ __('main.choose_a_photo') }}</label>
                            <input type="file" name="photo" class="form-control @error('photo', 'write') is-invalid @enderror" accept="image/*">

                            @error('photo', 'write')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                            <small class="form-hint">
                                {{__('main.extensions_allowed')}}
                            </small>
                        </div>

                        <div class="mb-3">
                            <div class="col">
                                <div class="form-selectgroup form-selectgroup-pills @error('category_id', 'write') is-invalid @enderror">
                                @foreach($categories as $category)
                                <label class="form-selectgroup-item">
                                    <input type="radio" id="category_id" name="category_id" value="{{ $category->id }}" class="form-selectgroup-input" {{ old('category_id') == $category->id ? 'checked' : '' }} @if(Auth::user()->total_point_count()<$category->score) disabled @endif>
                                    <span class="form-selectgroup-label" @if(Auth::user()->total_point_count()<$category->score) data-bs-toggle="tooltip" data-bs-html="true" title="{{ __('points.form_notice1') }}" @endif>
                                        {{ $category->name }}
                                        </span>
                                        </label>
                                    @endforeach
                                    </div>

                                    @error('category_id', 'write')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror

                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">{{ __('main.tags') }}</label>
                            <input type="text" class="form-control @error('tags') is-invalid @enderror" name="tags" placeholder="{{ __('main.separate_tag') }}" value="{{ old('tags') }}">
                        </div>

                    </div>
                    
                    <input type="hidden" name="genders_id" value="{{ Auth::user()->genders_id }}">
                    <input type="hidden" name="age" value="{{ Carbon::now()->diffInYears(Auth::user()->birth) }}">
                    
                    <div class="modal-footer">

                        <!-- public -->
                        <label class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="public" value="1" {{ old('public') ? 'checked' : null }}>
                            <span class="form-check-label">Hiện danh tính của tôi</span>
                        </label>
                        <!-- end public -->

                        <button type="submit" class="btn btn-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><circle cx="12" cy="12" r="9"></circle><line x1="9" y1="12" x2="15" y2="12"></line><line x1="12" y1="9" x2="12" y2="15"></line></svg> {{ __('main.btn_send') }}
                        </button>
                    </div>
                            
            </form>
            @else
            <!-- if new stories are paused -->
            <div class="modal-body">
                <div class="text-center">
                    <img src="{{ asset('resources/views/assets/img/warning.svg') }}" alt="">
                </div>
                <div class="text-center">
                    <div class="empty-header">
                        {{ __('main.new_entries_paused') }}
                    </div>
                </div>
            </div>
            @endif
            <!-- end write story -->          
            @endif
        </div>
    </div>
</div>
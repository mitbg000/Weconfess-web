@extends('layouts.app')
@section('content')
<div class="row row-cards justify-content-center">
    <div class="col-lg-8">
        <div class="card flex-wrap mb-3 shadow @if($item->featured == 1) card-featured @endif">
            <div class="card-header {{ $item->gender->bg_color ?? "bg-white" }}">
                <div class="col">
                    <a href="{{ route('show', ['id'=>$item->id, 'slug'=>$item->slug]) }}" class="text-white text-decoration-none">
                        <h3 class="card-title text-post-title ">
                             #{{ $item->id, " " }}  {{ $item->title }}
                        </h3>
                    </a>
                </div>

                <div class="col-auto">
                    <div class="dropdown">
                     <a href="#" class="card-dropdown text-muted" data-bs-toggle="dropdown" aria-expanded="false">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-filled " width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="20" cy="2" r="1" /><circle cx="20" cy="8" r="1" /><circle cx="20" cy="14" r="1" /></svg>
                    </a>

                        <div class="dropdown-menu dropdown-menu-end">
                            @if(Auth::check() && Auth::id() == $item->user_id || Auth::check() && Auth::user()->isAdministrator())
                            <a href="{{ route('delete_user_post', $item->id) }}" onclick="return confirm('Do you confirm this operation?');" class="dropdown-item">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon dropdown-item-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="4" y1="7" x2="20" y2="7" /><line x1="10" y1="11" x2="10" y2="17" /><line x1="14" y1="11" x2="14" y2="17" /><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" /><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" /></svg> 
                                    {{ __('main.card_delete') }}
                                </a>
                            <!-- end actions enabled by the post user -->
                            @endif

                            <a href="{{ route('report', $item->id) }}" onclick="return confirm('Do you confirm this operation?');" class="dropdown-item text-warning">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon dropdown-item-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="5" y1="5" x2="5" y2="21" /><line x1="19" y1="5" x2="19" y2="14" /><path d="M5 5a5 5 0 0 1 7 0a5 5 0 0 0 7 0" /><path d="M5 14a5 5 0 0 1 7 0a5 5 0 0 0 7 0" /></svg>
                                {{ __('main.card_report') }}
                            </a>

                        </div>
                    </div>
                </div>

            </div>
            
            @if($item->photo()->exists())
             
			<img src="{{ asset('storage/app/'.$item->photo->filename) }}" alt="{{ $item->title }}" class="card-img-top img-responsive img-responsive-16by9" style=" opacity: 1;">
			
            @endif

            <div class="card-body">
          
                <div class="row">
                    @if(!is_null($item->public))
                    <div class="col-auto">
                        <a href="{{ route('profile', $item->user->name) }}">
                            <span class="avatar avatar-ms rounded" @if(!empty($item->user->avatar)) style="background-image: url({{ asset('storage/app/public/images/avatar/'.$item->user->avatar) }})" @endif>
                                @if(empty($item->user->avatar))
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="12" cy="7" r="4" /><path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" /></svg>
                                @endif
                                @if(Cache::has('user-is-online-' . $item->user->id))
                                <span class="badge bg-green" title="{{__('main.card_online')}}"></span>
                                @else
                                <span class="badge bg-x" title="{ __('main.card_offline')}}"></span>
                                @endif
                            </span>
                        </a>
                    </div>
                    @endif
                    <div class="col">
                        <h3>{!! nl2br(e( $item->story ))!!}</h3>

                        <p>
                            @foreach($item->tags as $tag)
                            <a href="{{ route('tag', ['slug' => $tag->slug]) }}" class="badge bg-azure-lt">
                                {{ $tag->slug }}
                            </a>
                            @endforeach
                        </p>

                    </div>
                </div>

            </div>

            <div class="card-footer">
                <div class="row g-2 mb-2 align-items-center">
                    <div class="col">
                        <a href="javascript:void(0);" onclick="likePost({{ $item->id }})">
                            <svg xmlns="http://www.w3.org/2000/svg" id="like-icon-{{ $item->id }}" class=" ld ld-breath icon   icon @if(Auth::check()) @if(Auth::user()->hasLiked($item)) icon-filled text-danger @else text-muted @endif @else text-muted @endif" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M19.5 13.572l-7.5 7.428l-7.5 -7.428m0 0a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.572" /></svg>
                        </a>
                        <span class="text-muted text-truncate"> 
                        <span id="like-{{ $item->id }}">@json($item->likers()->count())</span> {{ __('main.card_likes') }}
                    </span>
                    </div>

                    <!-- share -->
                    <div class="col-auto">
                         
                               
                                <a class="align-items-center" href="http://www.facebook.com/sharer/sharer.php?u={{ url('view/'.$item->id.'/'.$item->slug) }}&t={{ $item->title }}" target="_blank">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon-card " width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" /></svg>
                                   
                                </a>

                    </div>
                    <!-- end share -->

                    <!-- bookmark -->
                    <div class="col-auto">
                        <a href="javascript:void(0);" onclick="savePost({{ $item->id }})">
                            <svg xmlns="http://www.w3.org/2000/svg" id="save-icon-{{ $item->id }}" class="icon @if(Auth::check()) @if(Auth::user()->hasFavorited($item)) icon-filled @else text-muted @endif @else text-muted @endif" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 4h6a2 2 0 0 1 2 2v14l-5 -3l-5 3v-14a2 2 0 0 1 2 -2" /></svg>
                        </a>
                    </div>
                    <!-- end bookmark -->
                    <div class="col-auto morph-button morph-button-modal morph-button-modal-3 morph-button-fixed">
                     <img type="button" style="cursor=pointer;" src="https://weconfess.net/resources/views/assets/img/share.svg" alt="" height="25"> 
                        <div class="morph-content">
    <div>
      <div class="content-style-form"><span class="icon icon-close"></span>
        <h1 class="text-light strong">Weconfess</h1>
        <h1>#{{ $item->id, " " }}  {{ $item->title }}</h1>
       
        <form>
           <img style="border-radius:1rem; margin-top:30px"src="https://chart.googleapis.com/chart?cht=qr&chs=200x200&chl={{ route('show', ['id'=>$item->id, 'slug'=>$item->slug]) }}" />
            <h1>Links:</h1>
            <input type="text" value="{{ route('show', ['id'=>$item->id, 'slug'=>$item->slug]) }}" id="myInput" />
            
          </p>
          <p>
            <input class="button" onclick="myFunction()" type="submit" value="Sao chép links"/>
            
          </p>
          <script>
                 function myFunction() {
                   var copyText = document.getElementById("myInput");
                   copyText.select();
                   copyText.setSelectionRange(0, 99999);
                   navigator.clipboard.writeText(copyText.value);
  
                   var tooltip = document.getElementById("myTooltip");
                   tooltip.innerHTML = "Copied: " + copyText.value;
                }

                function outFunc() {
                   var tooltip = document.getElementById("myTooltip");
                   tooltip.innerHTML = "Copy to clipboard";
                }
          </script>

        </form>
      </div>
      
    </div>
  </div>
 
                     </div>
                </div>

                <div class="row small strong">

                    

                    <div class="col d-flex align-items-center pe-2">
                        <span class="text-muted text-truncate">
                            {{ $item->itemView() }} {{ __('main.card_views')  }} &emsp;{{ $item->created_at->diffForHumans() }}
                        </span>
                    </div>
                    

                </div>
            </div>
        </div>
        
        <div class="row mt-2">
            <div class="col">
                @include('layouts.item.comments')
            </div>
        </div>
        
    </div>
    
    <div class="col-lg-4">
        
        <!-- Top Users -->
        @if($statusPoints == 1)
        @include('layouts.topUsers')
        @endif
        <!-- End Top Users -->
        
        <!-- ads -->
        @if(!empty($setting_adv_top))
        @if($adv_top->status == 1)
        <div class="mb-3">
            {!! $adv_top->value !!}
        </div>
        @endif
        @endif
        <!-- end ads -->
        
@forelse($randomItems as $item)
        <div class="card card-sm mb-3 shadow">
            <div class="card-header {{ $item->gender->bg_color ?? "bg-white" }}">
                <div class="col">
                    <a href="{{ route('show', ['id'=>$item->id, 'slug'=>$item->slug]) }}" class="text-post-title text-decoration-none">
                        <span class="text-post-title strong">
                             #{{ $item->id, " " }}  {{ $item->title }}
                        </span>
                    </a>
                </div>
            </div>
                
            <div class="card-body">
                <p class="small" >
                    {{ Str::limit($item->story, 150) }}
                </p>
				<div class="row small strong">

                <div class="col-auto d-flex align-items-center pe-2">
                    <span class="text-muted text-truncate"> 
                        <span id="like-{{ $item->id }}">@json($item->likers()->count())</span> {{ __('main.card_likes') }}
                    </span>
                </div>

                <div class="col d-flex align-items-center pe-2">
                    <span class="text-muted text-truncate">
                        {{ $item->itemView() }} {{ __('main.card_views') }} &ensp;
                        {{ $item->created_at->diffForHumans() }}
                    </span>
                </div>

                <div class="col-auto align-items-center">
                     <a href="{{ route('show', ['id'=>$item->id, 'slug'=>$item->slug]) }}" class="btnextra strong" >
                    {{ __('Đọc thêm') }}
                </a>
                </div>
            </div>
                
				
            </div>

        </div>
        @empty
        {{ __('There are no stories to show.') }}
        @endforelse
        
        <!-- ads -->
        @if(!empty($setting_adv_bottom))
        @if($adv_bottom->status == 1)
        <div class="mb-3">
            {!! $adv_bottom->value !!}
        </div>
        @endif
        @endif
        <!-- end ads -->
        
    </div>
    
</div>
@endsection('content')
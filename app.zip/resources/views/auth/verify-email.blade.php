@extends('layouts.guest')
@section('content')
<div class="container-tight py-6">
    
    <div class="text-center mt-4 mb-4">
        <a href="{{ url('/') }}" class="navbar-brand2 d-none-navbar-horizontal pr-0 pr-md-3">
            {{ $site_name }}
        </a>
    </div>

    <div class="card-setting card-md shadow">

        <div class="card-header">
            <h3 class="card-title">{{ __('Đặt lại mật khẩu') }}</h3>
        </div>
        
        <div class="mb-4 text-sm text-gray-600">
            {{ __('cảm ơn vì đã đăng kí! Trước khi bắt đầu, Bạn có thể xác nhận tài khoản bằng cách click vào link chúng tôi đã gửi cho bạn qua địa chỉ email? Nếu bạn không nhận được chúng tôi sẽ gửi lại một cái mới.') }}
        </div>

        @if (session('status') == 'verification-link-sent')
            <div class="mb-4 font-medium text-sm text-green-600">
                {{ __('Một đường link xác nhận đã được gửi đến email mà bạn cung cấp trong quá trình đăng kí.') }}
            </div>
        @endif
        
        <form method="POST" action="{{ route('verification.send') }}">
            @csrf
            
            <div class="card-body">
                <button class="btn btn-primary" type="submit">{{ __('Gửi lại email xác nhận') }}</button>
            </div>
        </form>
        
        <form method="POST" action="{{ route('logout') }}">
            @csrf

                <button type="submit" class="underline text-sm text-gray-600 hover:text-gray-900">
                    {{ __('Đăng xuất') }}
                </button>

            </form>
        
    </div>
    
</div>
@endsection
@extends('layouts.guest')
@section('content')
<div class="flex-fill d-flex flex-column justify-content-center py-4">
    <div class="container-tight py-6">
        
        <div class="text-center mb-4">
            <a href="{{ url('/') }}" class="navbar-brand2 d-none-navbar-horizontal pr-0 pr-md-3">
                {{ $site_name }}
            </a>
        </div>
        
        <form class="card-setting card-md shadow" action="{{ route('register') }}" method="post">
            {{ csrf_field() }}
            <div class="card-body">
                <h2 class="card-title text-center mb-4">Tạo tài khoản mới</h2>
                <div class="mb-3">
                    <label class="form-label">Tên đăng nhập</label>
                    <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                    @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            
                <div class="mb-3">
                    <label class="form-label">Địa chỉ emaill</label>
                    <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                    @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Mật khẩu</label>
                    <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="off">

                    @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Xác nhận mật khẩu</label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="off">
                </div>
                
                <div class="mb-3">
                    <label class="form-check">
                        <input type="checkbox" class="form-check-input" required autocomplete="off">
                        <span class="form-check-label">Đồng ý <a href="https://weconfess.net/page/dieu-khoan-va-bao-mat" tabindex="-1">Điều khoản và bảo mật</a>.</span>
                    </label>
                </div>
                
                <div class="form-footer">
                    <button type="submit" class="btn btn-primary w-100">{{ __('Tạo tài khoản mới') }}</button>
                </div>
            </div>
        </form>

    </div>
    
    <div class="text-center text-muted mt-4">
        Đã có tài khoản? <a href="{{ url('login') }}" tabindex="-1">Đăng nhập</a>
    </div>
    
</div> 
@endsection
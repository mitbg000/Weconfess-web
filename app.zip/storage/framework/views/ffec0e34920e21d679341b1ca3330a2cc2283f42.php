<div class="card shadow mb-4">
    
    <div class="card-body">
        <h2 class="form-label"><?php echo e(__('main.card_comments_header', ['count' => $item->comments()->count()])); ?></h2>
        <form method="POST" action="<?php echo e(route('store')); ?>" role="form" id="post-comment">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <textarea type="text" class="form-control form-control-flush <?php $__errorArgs = ['comment_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2" name="comment_text" placeholder="<?php echo e(__('main.card_add_public_comment')); ?>"><?php echo e(old('comment_text')); ?></textarea>

                    <?php $__errorArgs = ['comment_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="col-auto">
                    <input type="hidden" id="recipient_id" name="recipient_id" value="<?php echo e($item->user_id); ?>">
                    <input type="hidden" id="item_id" name="item_id" value="<?php echo e($item->id); ?>">
                    <button class="btn w-100">
                        <?php echo e(__('main.btn_send')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>

    <div class="card-body card-body-scrollable card-body-scrollable-shadow" style="height: calc(24rem + 10px)">
        <div class="divide-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $item->comments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row" id="comment-<?php echo e($comment->id); ?>">
                <div class="col-auto">
                    <a href="<?php echo e(url('profile/@'.$comment->user()->name)); ?>">
                        <span class="avatar rounded" <?php if(!empty($comment->user()->avatar)): ?> style="background-image: url(<?php echo e(asset('storage/app/public/images/avatar/'.$comment->user()->avatar)); ?>)" <?php endif; ?>>
                            <?php if(empty($comment->user()->avatar)): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="12" cy="7" r="4" /><path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" /></svg>
                            <?php endif; ?>

                            <?php if(Cache::has('user-is-online-' . $comment->user_id)): ?>
                            <span class="badge bg-green" title="<?php echo e(__('main.card_online')); ?>"></span>
                            <?php else: ?>
                            <span class="badge bg-x" title="<?php echo e(__('main.card_offline')); ?>"></span>
                            <?php endif; ?>
                        </span>
                    </a>
                </div>
                <div class="col">
                    <div class="text-muted">
                        <a href="<?php echo e(url('profile/@'.$comment->user()->name)); ?>"><strong><?php echo e($comment->user()->name); ?></strong></a> <?php if($item->user_id == $comment->user_id): ?><span class="badge badge-pill bg-red"><?php echo e(__('OP')); ?></span><?php endif; ?> <?php echo e($comment->comment_text); ?>

                    </div>
                    <div class="text-muted"><?php echo e(Carbon::parse($comment->created_at)->diffForHumans()); ?></div>
                </div>

                <?php if($comment->user_id == Auth::id()): ?>
                <div class="col-auto">
                    <a href="javascript:void(0);" onclick="deleteComment(<?php echo e($comment->id); ?>)" class="btn btn-link btn-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><line x1="4" y1="7" x2="20" y2="7"></line><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path></svg>
                    </a>
                </div>
                <?php endif; ?>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty">
                <div class="empty-img">
                    <img src="<?php echo e(asset('resources/views/assets/img/comments.svg')); ?>" alt="">
                </div>
                <p class="empty-title"><?php echo e(__('main.card_there_are_no_comments')); ?></p>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views/layouts/item/comments.blade.php ENDPATH**/ ?>
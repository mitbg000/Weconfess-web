<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e($page_name); ?> - <?php echo e($site_name); ?></title>
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('storage/app/public/images/logo/favicon/'.App\Models\Settings::find('favicon')->value)); ?>">

        <meta name="msapplication-TileColor" content="#206bc4"/>
        <meta name="theme-color" content="#206bc4"/>
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
        <meta name="apple-mobile-web-app-capable" content="yes"/>
        <meta name="mobile-web-app-capable" content="yes"/>
        <meta name="HandheldFriendly" content="True"/>
        <meta name="MobileOptimized" content="320"/>
        
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('resources/views/assets/css/tabler.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('resources/views/assets/css/toastr.css')); ?>">
        
        <script type="text/javascript">
            var APP_URL = <?php echo json_encode(url('/')); ?>

        </script>
        
    </head>
    <body class="font-sans antialiased">
        <div class="page">
            <?php echo $__env->make('admin.layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="content">
                <div class="container-xl">

                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        
        <!-- Scripts -->
        <script src="<?php echo e(asset('resources/views/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('resources/views/assets/js/tabler.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('resources/views/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('resources/views/assets/js/toastr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('resources/views/assets/js/extra.js')); ?>"></script>
        <?php echo toastr_js(); ?>
        <?php echo app('toastr')->render(); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>
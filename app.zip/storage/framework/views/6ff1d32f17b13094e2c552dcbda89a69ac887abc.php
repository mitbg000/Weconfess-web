<?php echo e($slot); ?>

<?php /**PATH /home/uqnfocmbhosting/public_html/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>

<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                <?php echo e($page_name); ?> (<?php echo e($post->title); ?>)
            </h2>
            
            <ol class="breadcrumb breadcrumb-alternate" aria-label="breadcrumbs">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin')); ?>">
                        <?php echo e($site_name); ?>

                    </a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin/posts')); ?>">
                        <?php echo e(__('Posts')); ?>

                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="#">
                        <?php echo e($page_name); ?>

                    </a>
                </li>
            </ol>
            
        </div>
    </div>
</div>

<div class="row row-cards">
    
    <div class="col-8">
        <div class="card">
            <form method="post" action="<?php echo e(route('update_edit_post', $post->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Title')); ?></label>
                        <div class="col">
                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('title')) ? old('title') : $post->title); ?>" name="title">

                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Story')); ?></label>
                        <div class="col">
                            <textarea class="form-control <?php $__errorArgs = ['story'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="story" rows="4"><?php echo e(!empty(old('story')) ? old('story') : $post->story); ?></textarea>
                            
                            <?php $__errorArgs = ['story'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Gender')); ?></label>
                        <div class="col">
                            <select class="form-control" name="genders_id">
                                <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gender->id); ?>" <?php echo e($post->genders_id == $gender->id ? 'selected' : ''); ?>>
                                    <?php echo e($gender->name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('URL')); ?></label>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo e($post->slug); ?>" readonly>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Categories')); ?></label>
                        <div class="col">
                            <div class="form-selectgroup form-selectgroup-pills">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="form-selectgroup-item">
                                    <input class="form-selectgroup-input" type="radio" name="category" value="<?php echo e($cat->id); ?>"
                                           <?php echo e($post->category()->first()->id == $cat->id ? 'checked' : ''); ?>>
                                    <span class="form-selectgroup-label"><?php echo e($cat->name); ?></span>
                                </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                            <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                </div>
            </form>
        </div>
        
    </div>
    
    <div class="col-4">
        <div class="card">
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('delete_tag', ['id'=>$post->id, 'tag'=>$tag->name])); ?>" onclick="return confirm('Do you confirm this operation?');" class="badge bg-azure-lt">
                    <?php echo e($tag->slug); ?> <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php echo e(__('There are no tags.')); ?>

                <?php endif; ?>
            </div>
        </div>
        
        <div class="card mt-2" style="height: calc(24rem + 10px)">
            <div class="card-header">
                <h2 class="card-title">
                    <?php echo e(__('People who love this post')); ?>

                </h2>
            </div>
            <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                <div class="divide-y-4">
                    <?php $__empty_1 = true; $__currentLoopData = $post->likers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div>
                        <div class="row">
                            <div class="col">
                                <div class="text-truncate">
                                    <strong><?php echo e($user->name); ?></strong>
                                </div>
                                <div class="text-muted"><?php echo e($post->created_at); ?></div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php echo e(__('Nobody likes it yet.')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
        
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views\admin\posts\edit_post.blade.php ENDPATH**/ ?>
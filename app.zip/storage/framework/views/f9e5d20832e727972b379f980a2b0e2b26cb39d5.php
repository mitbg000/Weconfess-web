
<?php $__env->startSection('content'); ?>

<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                <?php echo e($page_name); ?>

            </h2>
            
            <ol class="breadcrumb breadcrumb-alternate" aria-label="breadcrumbs">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin')); ?>">
                        <?php echo e($site_name); ?>

                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="#">
                        <?php echo e($page_name); ?>

                    </a>
                </li>
            </ol>
            
        </div>
        
        <div class="col-auto ms-auto d-print-none">
            <a href="<?php echo e(route('create_gender')); ?>" class="btn btn-primary">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg> <?php echo e(__('New Gender')); ?>

            </a>   
        </div>
        
    </div>
</div>

<div class="row row-cards row-deck">
    
    <div class="table-responsive">
        <table class="table table-vcenter table-nowrap">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Created</th>
                    <th>Updated</th>
                    <th class="w-2">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($gender->id); ?></td>
                    <td class="text-muted">
                        <span class="badge <?php echo e($gender->bg_color); ?>">
                            <?php echo e($gender->name); ?>

                        </span>
                    </td>
                    <td class="strong">
                        <span class="badge bg-indigo-lt">
                            <?php echo e($gender->slug); ?>

                        </span>
                    </td>
                    <td class="text-reset"><?php echo e($gender->created_at); ?></td>
                    <td class="text-reset"><?php echo e($gender->updated_at); ?></td>
                    <td>
                        <a href="<?php echo e(route('edit_gender', $gender->id)); ?>" class="btn btn-sm">
                            <?php echo e(__('Edit')); ?>

                        </a>
                        <a href="<?php echo e(route('delete_gender', $gender->id)); ?>" onclick="return confirm('Do you confirm this operation?');" class="btn btn-sm btn-icon btn-link">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon text-red" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="4" y1="7" x2="20" y2="7" /><line x1="10" y1="11" x2="10" y2="17" /><line x1="14" y1="11" x2="14" y2="17" /><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" /><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" /></svg>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <td><?php echo e(__('There are no genders.')); ?></td>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <?php echo e($genders->links()); ?>

    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views\admin\genders\index.blade.php ENDPATH**/ ?>
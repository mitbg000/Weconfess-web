


<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
        <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
        <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e($page_name); ?> - <?php echo e($site_name); ?></title>
        <meta name="description" content="<?php echo e(Str::limit($site_description,140, '...')); ?>">

        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('storage/app/public/images/logo/favicon/'.App\Models\Settings::find('favicon')->value)); ?>">

        <meta name="msapplication-TileColor" content="#206bc4"/>
        <meta name="theme-color" content="#206bc4"/>
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
        <meta name="apple-mobile-web-app-capable" content="yes"/>
        <meta name="mobile-web-app-capable" content="yes"/>
        <meta name="HandheldFriendly" content="True"/>
        <meta name="MobileOptimized" content="320"/>
        
        <meta name="twitter:image:src" content="">
        <meta name="twitter:site" content="<?php echo e($site_name); ?>">
        <meta name="twitter:card" content="summary">
        <meta name="twitter:title" content="<?php echo e($site_name); ?> - <?php echo e($page_name); ?>">
        <meta name="twitter:description" content="<?php echo e(Str::limit($site_description,140, '...')); ?>">
        <meta property="og:image" content="<?php echo e($site_og_image ?? "https://weconfess.net/weconfess.png"); ?>">
        <meta property="fb:app_id" content="340112427520784" />
        <meta property="og:image:width" content="1200">
        <meta property="og:image:height" content="600">
        <meta property="og:site_name" content="<?php echo e($site_name); ?>">
        <meta property="og:type" content="object">
        <meta property="og:title" content="<?php echo e($site_name); ?> - <?php echo e($page_name); ?>">
        <meta property="og:url" content="<?php echo e(Request::url()); ?>">
        <meta property="og:description" content="<?php echo e(Str::limit($site_description,150, '...')); ?>">
    
      
    
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('resources/views/assets/css/tabler.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('resources/views/assets/css/toastr.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('resources/views/assets/css/extra.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('resources/views/assets/css/loading.min.css')); ?>">
       
      <!-- Logo animation -->
        <link rel='stylesheet' href='https://s3-us-west-2.amazonaws.com/s.cdpn.io/199011/bebas.css'>
        <link rel="stylesheet" href="<?php echo e(asset('resources/views/assets/css/logo.css')); ?>">
      <!-- chrome app -->
      <link rel="manifest" href="manifest.json">
      <script> 
		//serice worker supported by browser
		if ('serviceWorker' in navigator) {
			navigator.serviceWorker.register('service-worker.js');
		};
	</script>
      
        <script type="text/javascript">"use strict";var APP_URL = <?php echo json_encode(url('/')); ?></script>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5268350932405318"
     crossorigin="anonymous"></script>
    
    </head>
     
    <body class="font-sans antialiased">
           
        <div class="page">
            <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="content">
                <div class="container-xl">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
        <!-- Scripts -->
        <script src="<?php echo e(asset('resources/views/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('resources/views/assets/js/tabler.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('resources/views/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('resources/views/assets/js/masonry.pkgd.min.js')); ?>"></script>
        <script src="<?php echo e(asset('resources/views/assets/js/toastr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('resources/views/assets/js/extra.js')); ?>"></script>
        <?php echo toastr_js(); ?>
        <?php echo app('toastr')->render(); ?>
        <?php if(count($errors->write->all()) > 0): ?>
        <script type="text/javascript">jQuery(document).ready(function(){jQuery("#modal--write--story").modal("show")});</script>
        <?php endif; ?>

          <!-- JS logo animation -->
	
          <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
           <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/velocity/1.1.0/velocity.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js'></script>
          <script  src="<?php echo e(asset('resources/views/assets/js/logo.js')); ?>"></script>
          
          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('resources/views/assets/js/html2canvas.min.js')); ?>"></script>
    </body>
</html><?php /**PATH /home/uqnfocmbhosting/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>
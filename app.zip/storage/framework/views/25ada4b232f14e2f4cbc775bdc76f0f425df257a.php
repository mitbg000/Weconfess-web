<?php $__env->startSection('content'); ?>
<div class="container-tight py-6">
    
    <div class="text-center mt-4 mb-4">
        <a href="<?php echo e(url('/')); ?>" class="navbar-brand2 d-none-navbar-horizontal pr-0 pr-md-3">
            <?php echo e($site_name); ?>

        </a>
    </div>

    <div class="card-setting">

        <div class="card-header">
            <h3 class="card-title"><?php echo e(__('Quên mật khẩu')); ?></h3>
        </div>
        
        <div class="card-body">
            <?php echo e(__('Bạn quên mật khẩu ư? Không sao cả. Chỉ cần cho chúng tôi biết địa chỉ email của bạn và chúng tôi sẽ gửi cho bạn một đường link thiết lập mất khẩu mới vào địa chỉ email của bạn.')); ?>

        </div>
        
        <!-- Session Status -->
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label"><?php echo e(__('Email')); ?></label>
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="form-footer">
                    <button type="submit" class="btn btn-primary w-100"><?php echo e(__('Gửi link đặt lại mật khẩu')); ?></button>
                </div>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/uqnfocmbhosting/public_html/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>
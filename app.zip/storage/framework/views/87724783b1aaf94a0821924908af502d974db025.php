
<?php $__env->startSection('content'); ?>

<div class="row" data-masonry='{"percentPosition": true }'>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 
    <?php if(!empty($setting_adv_top)): ?>
    <?php if($adv_top->status == 1): ?>
    <?php if($loop->first): ?>
    <div class="col-lg-3">
        <div class="mb-3">
            <?php echo $adv_top->value; ?>

        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>
    
    <?php if(!empty($setting_adv_bottom)): ?>
    <?php if($adv_bottom->status == 1): ?>
    <?php if($loop->last): ?>
    <div class="col-lg-3">
        <div class="mb-3">
            <?php echo $adv_bottom->value; ?>

        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>
    
    <?php echo $__env->make('layouts.item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
   
    <?php if($items->isEmpty()): ?>
    <?php echo $__env->make('layouts.blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
   
    
</div>

<div class="row">
    <div class="col-lg-12">
        <?php echo e($items->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/uqnfocmbhosting/public_html/resources/views/index.blade.php ENDPATH**/ ?>
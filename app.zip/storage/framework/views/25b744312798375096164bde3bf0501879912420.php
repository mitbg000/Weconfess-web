<?php $__env->startSection('content'); ?>
<div class="container-tight py-6">
    
    <div class="text-center mt-4 mb-4">
        <a href="<?php echo e(url('/')); ?>" class="navbar-brand d-none-navbar-horizontal pr-0 pr-md-3">
            <?php echo e($site_name); ?>

        </a>
    </div>

    <div class="card card-md shadow">

        <div class="card-header">
            <h3 class="card-title"><?php echo e(__('Reset Password')); ?></h3>
        </div>
        
        <div class="mb-4 text-sm text-gray-600">
            <?php echo e(__('Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn\'t receive the email, we will gladly send you another.')); ?>

        </div>

        <?php if(session('status') == 'verification-link-sent'): ?>
            <div class="mb-4 font-medium text-sm text-green-600">
                <?php echo e(__('A new verification link has been sent to the email address you provided during registration.')); ?>

            </div>
        <?php endif; ?>
        
        <form method="POST" action="<?php echo e(route('verification.send')); ?>">
            <?php echo csrf_field(); ?>
            
            <div class="card-body">
                <button class="btn btn-primary" type="submit"><?php echo e(__('Resend Verification Email')); ?></button>
            </div>
        </form>
        
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>

                <button type="submit" class="underline text-sm text-gray-600 hover:text-gray-900">
                    <?php echo e(__('Logout')); ?>

                </button>

            </form>
        
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views\auth\verify-email.blade.php ENDPATH**/ ?>
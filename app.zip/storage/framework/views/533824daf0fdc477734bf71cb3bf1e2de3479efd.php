<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>
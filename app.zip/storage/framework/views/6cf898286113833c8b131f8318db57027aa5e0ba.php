
<?php $__env->startSection('content'); ?>

<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                <?php echo e($page_name); ?>

            </h2>
            
            <ol class="breadcrumb breadcrumb-alternate" aria-label="breadcrumbs">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin')); ?>">
                        <?php echo e($site_name); ?>

                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="#">
                        <?php echo e($page_name); ?>

                    </a>
                </li>
            </ol>
            
        </div>
    </div>
</div>

<div class="row row-cards row-deck">

    <form method="POST" action="<?php echo e(route('update_points')); ?>">
    <?php echo csrf_field(); ?>
        
        <!-- config -->
        <div class="col-12">
            <div class="card shadow">

                <div class="card-header bg-dark">
                    <h2 class="card-title text-white">
                        <?php echo e(__('points.points_title')); ?>

                    </h2>
                </div>
                <div class="card-body">
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('points.status_points')); ?></label>
                        <div class="col">
                            <select class="form-control" name="status_points">
                                <option value="1" <?php echo e($settings::find('status_points')->value == 1 ? 'selected' : ''); ?>>
                                    <?php echo e(__('points.active')); ?>

                                </option>
                                <option value="0" <?php echo e($settings::find('status_points')->value == 0 ? 'selected' : ''); ?>>
                                    <?php echo e(__('points.pause')); ?>

                                </option>
                            </select>
                            <small class="form-hint">
                                <?php echo e(__('points.status_points_suggestion')); ?>

                            </small>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('points.status_points_for_new_entry')); ?></label>
                        <div class="col">
                            <select class="form-control" name="status_points_new_entry">
                                <option value="1" <?php echo e($settings::find('status_points_new_entry')->value == 1 ? 'selected' : ''); ?>>
                                    <?php echo e(__('points.active')); ?>

                                </option>
                                <option value="0" <?php echo e($settings::find('status_points_new_entry')->value == 0 ? 'selected' : ''); ?>>
                                    <?php echo e(__('points.pause')); ?>

                                </option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('points.status_points_for_like')); ?></label>
                        <div class="col">
                            <select class="form-control" name="status_points_like">
                                <option value="1" <?php echo e($settings::find('status_points_like')->value == 1 ? 'selected' : ''); ?>>
                                    <?php echo e(__('points.active')); ?>

                                </option>
                                <option value="0" <?php echo e($settings::find('status_points_like')->value == 0 ? 'selected' : ''); ?>>
                                    <?php echo e(__('points.pause')); ?>

                                </option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('points.status_points_for_comment')); ?></label>
                        <div class="col">
                            <select class="form-control" name="status_points_comments">
                                <option value="1" <?php echo e($settings::find('status_points_comments')->value == 1 ? 'selected' : ''); ?>>
                                    <?php echo e(__('points.active')); ?>

                                </option>
                                <option value="0" <?php echo e($settings::find('status_points_comments')->value == 0 ? 'selected' : ''); ?>>
                                    <?php echo e(__('points.pause')); ?>

                                </option>
                            </select>
                        </div>
                    </div>

                    <div class="hr-text hr-text-left"><?php echo e(__('points.scores')); ?></div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('points.points_for_new_entry')); ?></label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['points_new_entry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('points_new_entry')) ? old('points_new_entry') : $settings::find('points_new_entry')->value); ?>" name="points_new_entry">
                            <?php $__errorArgs = ['points_new_entry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('points.points_for_like')); ?></label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['points_like'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('points_like')) ? old('points_like') : $settings::find('points_like')->value); ?>" name="points_like">
                            <?php $__errorArgs = ['points_like'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('points.points_for_comment')); ?></label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['points_comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('points_comments')) ? old('points_comments') : $settings::find('points_comments')->value); ?>" name="points_comments">

                            <?php $__errorArgs = ['points_comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="hr-text hr-text-left"><?php echo e(__('points.final_badge')); ?></div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('points.final_badge')); ?></label>
                        <div class="col">
                            <select class="form-control" name="top_badge">
                                <option value="" <?php echo e($settings::find('top_badge')->value == null ? 'selected' : ''); ?>>
                                    <?php echo e(__('No selection')); ?>

                                </option>
                                <?php $__currentLoopData = $badges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($badge->id); ?>" <?php echo e($settings::find('top_badge')->value == $badge->id ? 'selected' : ''); ?>>
                                    <?php echo e($badge->name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <small class="form-hint">
                                <?php echo e(__('points.final_badge_suggestion')); ?>

                            </small>
                        </div>
                    </div>

                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('points.points_title')); ?></button>
                </div>

            </div>
        </div>
        <!-- end config -->
        
    
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/admin/points/index.blade.php ENDPATH**/ ?>
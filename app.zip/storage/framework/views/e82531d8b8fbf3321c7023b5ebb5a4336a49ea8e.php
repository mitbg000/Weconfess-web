
<?php $__env->startSection('content'); ?>

<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                <?php echo e($page_name); ?> (<?php echo e($user->name); ?>)
            </h2>
            
            <ol class="breadcrumb breadcrumb-alternate" aria-label="breadcrumbs">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin')); ?>">
                        <?php echo e($site_name); ?>

                    </a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin/users')); ?>">
                        <?php echo e(__('Users')); ?>

                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="#">
                        <?php echo e($page_name); ?>

                    </a>
                </li>
            </ol>
            
        </div>
    </div>
</div>

<div class="row row-cards">
    
    <div class="col-12">
        <div class="card">
            <form method="post" action="<?php echo e(route('update_edit_user', $user->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Avatar')); ?></label>
                        <div class="col">
                            <span class="avatar avatar-lg rounded" <?php if(!empty($user->avatar)): ?> style="background-image: url(<?php echo e(asset('storage/app/public/images/avatar/'.$user->avatar)); ?>)" <?php endif; ?>>
                                <?php if(empty($user->avatar)): ?>
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="12" cy="7" r="4" /><path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" /></svg>
                                <?php endif; ?>

                                <?php if(Cache::has('user-is-online-' . $user->id)): ?>
                                <span class="badge bg-green" title="<?php echo e(__('main.card_online')); ?>"></span>
                                <?php else: ?>
                                <span class="badge bg-x" title="<?php echo e(__('main.card_offline')); ?>"></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Username')); ?></label>
                        <div class="col">
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('name')) ? old('name') : $user->name); ?>" name="name">

                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Email')); ?></label>
                        <div class="col">
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('email')) ? old('email') : $user->email); ?>" name="email">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Role')); ?></label>
                        <div class="col">
                            <div class="form-selectgroup form-selectgroup-pills">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="form-selectgroup-item">
                                    <input class="form-selectgroup-input" type="radio" name="role[]" value="<?php echo e($role->name); ?>"
                                           <?php echo e($user->roles->first()->id == $role->id ? 'checked' : ''); ?>>
                                    <span class="form-selectgroup-label"><?php echo e($role->name); ?></span>
                                </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                            <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="hr-text"><?php echo e(__('Change Password')); ?></div>
                    
                    <div class="form-group mb-3 row">
                        <label for="password" class="form-label col-3 col-form-label">
                            <?php echo e(__('New Password')); ?>

                        </label>
                        <div class="col">
                            <input id="new_password" type="password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="new_password" autocomplete="new-password" value="<?php echo e(old('new_password')); ?>">

                            <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group mb-3 row">
                        <label for="new_confirm_password" class="form-label col-3 col-form-label">
                            <?php echo e(__('Confirm New Password')); ?>

                        </label>
                        <div class="col">
                            <input id="new_confirm_password" type="password" class="form-control" name="new_confirm_password" autocomplete="new_confirm_password">
                        </div>
                    </div>

                

                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                </div>
            </form>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/uqnfocmbhosting/public_html/resources/views/admin/users/edit_user.blade.php ENDPATH**/ ?>
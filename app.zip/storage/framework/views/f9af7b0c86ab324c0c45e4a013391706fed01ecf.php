<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
    <span class="logo">
        <?php echo app('translator')->get('mail.app_name'); ?>
    </span>
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\xampp\htdocs\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<!-- Row -->
<div class="row justify-content-center">
    <div class="col-lg-9">
        <div class="card">
            
            <div class="card-header">
                <h2 class="card-title">
                    <?php echo e($page->title); ?>

                </h2>
            </div>
            
            <div class="card-body">
                
                <?php echo clean($page->body); ?>

                
            </div>
        </div>
    </div>
    
</div>
<!-- end Row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/layouts/pages/show.blade.php ENDPATH**/ ?>
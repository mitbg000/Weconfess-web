
<?php $__env->startSection('content'); ?>
<!-- latest Items Section -->
<div class="row" data-masonry='{"percentPosition": true }'>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <!-- ads top -->
    <?php if(!empty($setting_adv_top)): ?>
    <?php if($adv_top->status == 1): ?>
    <?php if($loop->first): ?>
    <div class="col-lg-3">
        <div class="mb-3">
            <?php echo $adv_top->value; ?>

        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>
    <!-- end ads -->
    
    <!-- ads bottom -->
    <?php if(!empty($setting_adv_bottom)): ?>
    <?php if($adv_bottom->status == 1): ?>
    <?php if($loop->last): ?>
    <div class="col-lg-3">
        <div class="mb-3">
            <?php echo $adv_bottom->value; ?>

        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>
    <!-- end ads -->

    <!-- items -->
    <?php echo $__env->make('layouts.item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end items -->
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <!-- if the list is empty -->
    <?php if($items->isEmpty()): ?>
    <?php echo $__env->make('layouts.blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <!-- end if the list is empty -->
    
</div>

<div class="row">
    <div class="col-lg-12">
        <?php echo e($items->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views/index.blade.php ENDPATH**/ ?>
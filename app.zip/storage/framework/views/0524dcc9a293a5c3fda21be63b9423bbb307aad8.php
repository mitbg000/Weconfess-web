
<?php $__env->startSection('content'); ?>

<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                <?php echo e($page_name); ?>

            </h2>
            
            <ol class="breadcrumb breadcrumb-alternate" aria-label="breadcrumbs">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin')); ?>">
                        <?php echo e($site_name); ?>

                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="#">
                        <?php echo e($page_name); ?>

                    </a>
                </li>
            </ol>
            
        </div>
    </div>
</div>

<div class="row row-cards row-deck">

    <form method="POST" action="<?php echo e(route('update_settings')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
        <!-- seo title e meta tag -->
        <div class="col-12">
            
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            
            <div class="card shadow mb-4">

                <div class="card-header bg-dark">
                    <h2 class="card-title text-white">
                        <?php echo e(__('Logo & Favicon')); ?>

                    </h2>
                </div>
                <div class="card-body">
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Logo</label>
                        <div class="col">
                            
                            <?php if(!empty($settings::find('logo_image')->value)): ?>
                            <div class="mb-2">
                                <img src="<?php echo e(asset('storage/app/public/images/logo/'.App\Models\Settings::find('logo_image')->value)); ?>" class="rounded" title="<?php echo e($site_name); ?>">

                                <a href="<?php echo e(route('delete_logo')); ?>" class="btn btn-link btn-icon text-danger">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="4" y1="7" x2="20" y2="7" /><line x1="10" y1="11" x2="10" y2="17" /><line x1="14" y1="11" x2="14" y2="17" /><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" /><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" /></svg>
                                </a>
                                
                            </div>
                            <?php endif; ?>
                            
                            <input type="file" name="logo_image" class="form-control form-control-lg <?php $__errorArgs = ['logo_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['logo_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>


                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Favicon</label>
                        <div class="col">
                            
                            <?php if(!empty($settings::find('favicon')->value)): ?>
                            <div class="mb-2">
                                <img src="<?php echo e(asset('storage/app/public/images/logo/favicon/'.App\Models\Settings::find('favicon')->value)); ?>" class="rounded" title="<?php echo e($site_name); ?>">

                                <a href="<?php echo e(route('delete_favicon')); ?>" class="btn btn-link btn-icon text-danger">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="4" y1="7" x2="20" y2="7" /><line x1="10" y1="11" x2="10" y2="17" /><line x1="14" y1="11" x2="14" y2="17" /><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" /><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" /></svg>
                                </a>
                                
                            </div>
                            <?php endif; ?>
                            
                            <input type="file" name="favicon" class="form-control form-control-lg <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                </div>

            </div>
            
            
            
            <div class="card shadow">

                <div class="card-header bg-dark">
                    <h2 class="card-title text-white">
                        <?php echo e(__('Title & Meta Tag')); ?>

                    </h2>
                </div>
                <div class="card-body">
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Title</label>
                        <div class="col">
                            <input type="text" class="form-control form-control-lg <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('site_name')) ? old('site_name') : $settings::find('site_name')->value); ?>" name="site_name">

                            <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Tagline</label>
                        <div class="col">
                            <input type="text" class="form-control form-control-lg <?php $__errorArgs = ['site_tagline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('site_tagline')) ? old('site_tagline') : $settings::find('site_tagline')->value); ?>" name="site_tagline">
                            <small class="form-hint">
                                <?php echo e(__('Simple words, like a motto on your website.')); ?>

                            </small>

                            <?php $__errorArgs = ['site_tagline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Description</label>
                        <div class="col">
                            <textarea class="form-control form-control-lg <?php $__errorArgs = ['site_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-bs-toggle="autosize" style="overflow: hidden; overflow-wrap: break-word; resize: none; height: 56px;" name="site_description"><?php echo e(!empty(old('site_description')) ? old('site_description') : $settings::find('site_description')->value); ?></textarea>
                            <small class="form-hint">
                                <?php echo e(__('A brief but accurate description. We recommend a maximum of 155 characters.')); ?>

                            </small>

                            <?php $__errorArgs = ['site_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>


                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                </div>

            </div>
        </div>
        <!-- end seo title e meta tag -->

        <!-- config -->
        <div class="col-12 mt-4">
            <div class="card shadow">

                <div class="card-header bg-dark">
                    <h2 class="card-title text-white">
                        <?php echo e(__('Configuration')); ?>

                    </h2>
                </div>
                <div class="card-body">
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Pause New Posts')); ?></label>
                        <div class="col">
                            <select class="form-control" name="active_upload">
                                <option value="1" <?php echo e($settings::find('active_upload')->value == 1 ? 'selected' : ''); ?>>
                                    <?php echo e(__('Active')); ?>

                                </option>
                                <option value="0" <?php echo e($settings::find('active_upload')->value == 0 ? 'selected' : ''); ?>>
                                    <?php echo e(__('Pause')); ?>

                                </option>
                            </select>
                            <small class="form-hint">
                                <?php echo e(__('Pause new entries, a warning will be shown.')); ?>

                            </small>
                        </div>
                    </div>

                    <div class="hr-text hr-text-left"><?php echo e(__('Posts')); ?></div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Results Per Page</label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['results_per_page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('results_per_page')) ? old('results_per_page') : $settings::find('results_per_page')->value); ?>" name="results_per_page">
                            <small class="form-hint">
                                <?php echo e(__('How many results per page you want to show.')); ?>

                            </small>

                            <?php $__errorArgs = ['results_per_page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Minimum Characters</label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['minimum_characters'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('minimum_characters')) ? old('minimum_characters') : $settings::find('minimum_characters')->value); ?>" name="minimum_characters">
                            <small class="form-hint">
                                <?php echo e(__('How many minimum characters are available for each story.')); ?>

                            </small>

                            <?php $__errorArgs = ['minimum_characters'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Maximum Characters</label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['maximum_characters'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('maximum_characters')) ? old('maximum_characters') : $settings::find('maximum_characters')->value); ?>" name="maximum_characters">
                            <small class="form-hint">
                                <?php echo e(__('How many maximum characters are available for each story.')); ?>

                            </small>

                            <?php $__errorArgs = ['maximum_characters'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Maximum Preview Chars</label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['story_preview_chars'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('story_preview_chars')) ? old('story_preview_chars') : $settings::find('story_preview_chars')->value); ?>" name="story_preview_chars">
                            <small class="form-hint">
                                <?php echo e(__('How many characters to show for the preview of each story.')); ?>

                            </small>

                            <?php $__errorArgs = ['story_preview_chars'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">New Entries</label>
                        <div class="col">
                            <select class="form-control" name="new_entries">
                                <option value="1" <?php echo e($settings::find('new_entries')->value == 1 ? 'selected' : ''); ?>>
                                    <?php echo e(__('Immediately visible')); ?>

                                </option>
                                <option value="2" <?php echo e($settings::find('new_entries')->value == 2 ? 'selected' : ''); ?>>
                                    <?php echo e(__('In moderation')); ?>

                                </option>
                            </select>
                            <small class="form-hint">
                                <?php echo e(__('Set whether new entries will be already visible by default or in moderation.')); ?>

                            </small>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Words Censored')); ?></label>
                        <div class="col">
                            <select class="form-control" name="words_censored">
                                <option value="0" <?php echo e($settings::find('words_censored')->value == 0 ? 'selected' : ''); ?>>
                                    <?php echo e(__('Inactive')); ?>

                                </option>
                                <option value="1" <?php echo e($settings::find('words_censored')->value == 1 ? 'selected' : ''); ?>>
                                    <?php echo e(__('Active')); ?>

                                </option>
                            </select>
                            <small class="form-hint">
                                <?php echo e(__("Enable or Disable Word Censorship. You can add or edit new words by opening and editing the file within the path: vendor\snipe\banbuilder\src\dict\dictionary.php")); ?>

                            </small>
                        </div>
                    </div>
                    
                    <div class="hr-text hr-text-left"><?php echo e(__('Comments')); ?></div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Minimum Characters</label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['min_characters_comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('min_characters_comment')) ? old('min_characters_comment') : $settings::find('min_characters_comment')->value); ?>" name="min_characters_comment">
                            <small class="form-hint">
                                <?php echo e(__('How many minimum characters are available for each comment.')); ?>

                            </small>

                            <?php $__errorArgs = ['min_characters_comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Maximum Characters</label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['max_characters_comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('max_characters_comment')) ? old('max_characters_comment') : $settings::find('max_characters_comment')->value); ?>" name="max_characters_comment">
                            <small class="form-hint">
                                <?php echo e(__('How many maximum characters are available for each comment.')); ?>

                            </small>

                            <?php $__errorArgs = ['max_characters_comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="hr-text hr-text-left"><?php echo e(__('Widgets')); ?></div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Random Items</label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['random_items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('random_items')) ? old('random_items') : $settings::find('random_items')->value); ?>" name="random_items">
                            <small class="form-hint">
                                <?php echo e(__('How many items to show in the "Random Items" widget.')); ?>

                            </small>

                            <?php $__errorArgs = ['random_items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Random Users</label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['random_users'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('random_users')) ? old('random_users') : $settings::find('random_users')->value); ?>" name="random_users">
                            <small class="form-hint">
                                <?php echo e(__('How many users to show in the "Random Users" widget.')); ?>

                            </small>

                            <?php $__errorArgs = ['random_users'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    
                    <div class="hr-text hr-text-left"><?php echo e(__('Reports')); ?></div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Alert Reports</label>
                        <div class="col">
                            <input type="number" class="form-control <?php $__errorArgs = ['alert_reports'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(!empty(old('alert_reports')) ? old('alert_reports') : $settings::find('alert_reports')->value); ?>" name="alert_reports">
                            <small class="form-hint">
                                <?php echo e(__('How many reports must a post receive to be subjected to examination. A post after receiving "X" reports will be shown in the "Reports" section.')); ?>

                            </small>

                            <?php $__errorArgs = ['alert_reports'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                </div>

            </div>
        </div>
        <!-- end config -->
        
        <div class="card shadow mt-4">

            <div class="card-header bg-dark">
                <h2 class="card-title text-white">
                    <?php echo e(__('Advertising')); ?>

                </h2>
            </div>
            <div class="card-body">

                <div class="form-group mb-3 row">
                    <label class="form-label col-3 col-form-label">Top</label>
                    <div class="col">
                        <select class="form-control" name="adv_top">
                        <?php $__currentLoopData = $advertising; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($adv->id); ?>" <?php echo e($adv->id == $settings::find('adv_top')->value ? 'selected' : ''); ?>>
                                <?php echo e($adv->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="" <?php echo e($settings::find('adv_top')->value == null ? 'selected' : ''); ?>>
                                <?php echo e(__('No advertising')); ?>

                            </option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group mb-3 row">
                    <label class="form-label col-3 col-form-label">Bottom</label>
                    <div class="col">
                        <select class="form-control" name="adv_bottom">
                        <?php $__currentLoopData = $advertising; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($adv->id); ?>" <?php echo e($adv->id == $settings::find('adv_bottom')->value ? 'selected' : ''); ?>>
                                <?php echo e($adv->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="" <?php echo e($settings::find('adv_bottom')->value == null ? 'selected' : ''); ?>>
                                <?php echo e(__('No advertising')); ?>

                            </option>
                        </select>
                    </div>
                </div>


            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
            </div>

        </div>
    
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<div class="page-header text-white d-print-none">
    <div class="row align-items-center">
        <div class="col-auto">
            <span class="avatar avatar-rounded bg-yellow-lt">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-filled" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 4h6a2 2 0 0 1 2 2v14l-5 -3l-5 3v-14a2 2 0 0 1 2 -2" /></svg>
            </span>
        </div>
        <div class="col">
            <h2 class="page-title">
                <?php echo e(__('main.saved')); ?>    
            </h2>
        </div>
    </div>
</div>
<!-- latest Items Section -->
<div class="row" data-masonry='{"percentPosition": true }'>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('layouts.item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php if($items->isEmpty()): ?>
    <?php echo $__env->make('layouts.blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
</div>

<div class="row">
    <div class="col-lg-12">
        <?php echo e($items->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/uqnfocmbhosting/public_html/resources/views/layouts/account/saved.blade.php ENDPATH**/ ?>